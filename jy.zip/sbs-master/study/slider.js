$(document).ready(function(){
    $(".section > .slider-wrap > .slider").slick({
      slidesToShow: 3,
      slidesToScroll: 3 ,
      // swipeToSlide: true , 
    })
  })