$(document).ready(function(){
  
    var controller = new ScrollMagic.Controller();

    let sec01_ani01 = gsap.to(".section02 > .move-box" ,{
      "left" : "90%" ,
      duration: 3 ,
    })

    let scene01 = new ScrollMagic.Scene({
      triggerElement: ".section02", // 스타트 지점을 생성
      offset: 100 , // 스타트 지점을 이동
      triggerHook: 0.3 , // 트리거 위치 지정
      duration: 300, // 애니메이션이 작동되는 길이 생성 안쓰면 애니메이션이 시간초대로 움직임
    });

  scene01.setTween(sec01_ani01); // 애니메이션 등록
  scene01.addTo(controller); // 컨트롤러 등록
  scene01.addIndicators(); // 인디케이터 등록

  let sec02_tl = gsap.timeline()
  
  let sec02_ani01 = gsap.from(".section03 > .move01" , {
    "opacity": 0 ,
    y : "50px" ,
  })
  let sec02_ani02 = gsap.from(".section03 > .move02" , {
    "opacity": 0 ,
    y : "50px" ,
  })
  let sec02_ani03 = gsap.from(".section03 > .move03" , {
    "opacity": 0 ,
    y : "50px" ,
  })
  sec02_tl.add(sec02_ani01)
  sec02_tl.add(sec02_ani02,0.2)
  sec02_tl.add(sec02_ani03,0.4)
  
  
  let scene02 = new ScrollMagic.Scene({
    triggerElement: ".section03", // 스타트 지점을 생성
    offset: 100 , // 스타트 지점을 이동
    triggerHook: 0.3 , // 트리거 위치 지정
  });

  scene02.setTween(sec02_tl); // 애니메이션 등록
  scene02.addTo(controller); // 컨트롤러 등록
  scene02.addIndicators(); // 인디케이터 등록
  

  let scene03 = new ScrollMagic.Scene({
    triggerElement: ".section04", // 스타트 지점을 생성
    offset: 100 , // 스타트 지점을 이동
    triggerHook: 0.3 , // 트리거 위치 지정
  });
  scene03.setClassToggle(".section04 > .move-box" , "active")
  scene03.addTo(controller); // 컨트롤러 등록
  scene03.addIndicators(); // 인디케이터 등록

  
  
})