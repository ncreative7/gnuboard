$(".test").click(function(){
  //   gsap.from(".test", {
  //     "width": "200px" ,
  //     duration: 1 ,
  //     // delay: 1 ,
  //   } );
  
  //   gsap.from(".test", {
  //     "background-color": "purple" ,
  //     duration: 1 ,
  //     delay: 1 ,
  //   } );
    
    let timeline = gsap.timeline({})
    timeline.to(".test", {
      "width": "300px" ,
    })
    timeline.to(".test",{
      "height" : "300px" ,
    })
    
    
  })
  
  // $(".test").click(function(){
  //     let timeline = gsap.timeline({})
  //     let ani01 = gsap.to(".test", {
  //       "width": "300px" ,
  //     })
  //     let ani02 = gsap.to(".test", {
  //       "height": "300px" ,
  //     })
  //     timeline.add(ani01)
  //     timeline.add(ani02) 변수로
      
      
  //   })
    
      