$(document).ready(function(){
  
    $(".btn").click(function(){
      // $("html , body").scrollTop(800)
      $("html , body").animate({
        "scrollTop": 0 ,
      },3000)
    })
    
  })
  
  $(window).scroll(function(){
    let scrollTop = $(this).scrollTop()
    
    console.log(scrollTop)
    if(scrollTop>=600){
      $(".btn").addClass("active")
    } else if(scrollTop < 300){
      $(".btn").removeClass("active")
    }
  })